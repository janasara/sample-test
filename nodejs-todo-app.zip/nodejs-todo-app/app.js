const express = require('express');
const connectDB = require('./config/db');
const dotenv = require('dotenv');
const logger = require('./middlewares/logger');
const todoRoutes = require('./routes/todoRoutes');

dotenv.config();
connectDB();

const app = express();

// Middleware
app.use(express.json()); // For parsing application/json
app.use(logger);         // Log incoming requests

// Routes
app.use('/api', todoRoutes);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
