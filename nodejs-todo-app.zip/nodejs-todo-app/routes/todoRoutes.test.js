const request = require('supertest');
const express = require('express');
const Todo = require('../models/todo');
const todoRoutes = require('../routes/todoRoutes');

// Setup express app with the todo routes
const app = express();
app.use(express.json()); // parse JSON request body
app.use('/api', todoRoutes); // route under '/api'

jest.mock('../models/todo'); // mock the Todo model

describe('Todo API Routes', () => {

  afterEach(() => {
    jest.clearAllMocks(); // clear mocks after each test
  });

  // Test GET /todos
  describe('GET /todos', () => {
    it('should return all todos', async () => {
      const todos = [
        { _id: '1', title: 'Todo 1', description: 'First todo', completed: false },
        { _id: '2', title: 'Todo 2', description: 'Second todo', completed: true },
      ];
      Todo.find.mockResolvedValue(todos); // mock the .find() method

      const res = await request(app).get('/api/todos');
      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveLength(2);
      expect(res.body[0].title).toBe('Todo 1');
      expect(res.body[1].completed).toBe(true);
    });

    it('should return 500 if there is a server error', async () => {
      Todo.find.mockRejectedValue(new Error('Server Error')); // mock a rejection

      const res = await request(app).get('/api/todos');
      expect(res.statusCode).toEqual(500);
      expect(res.body.message).toBe('Server Error');
    });
  });

  // Test POST /todos
  describe('POST /todos', () => {
    it('should create a new todo', async () => {
      const newTodo = { _id: '3', title: 'New Todo', description: 'Test description', completed: false };
      Todo.prototype.save = jest.fn().mockResolvedValue(newTodo); // mock .save() method

      const res = await request(app).post('/api/todos').send({
        title: 'New Todo',
        description: 'Test description',
        completed: false,
      });

      expect(res.statusCode).toEqual(201);
      expect(res.body.title).toBe('New Todo');
      expect(res.body.completed).toBe(false);
    });

    it('should return 400 if validation fails', async () => {
      const res = await request(app).post('/api/todos').send({
        description: 'Missing title',
      });

      expect(res.statusCode).toEqual(400);
      expect(res.body.message).toMatch(/"title" is required/);
    });
  });

  // Test PUT /todos/:id
  describe('PUT /todos/:id', () => {
    it('should update a todo by id', async () => {
      const updatedTodo = { _id: '1', title: 'Updated Todo', description: 'Updated description', completed: true };
      Todo.findByIdAndUpdate.mockResolvedValue(updatedTodo); // mock .findByIdAndUpdate()

      const res = await request(app).put('/api/todos/1').send({
        title: 'Updated Todo',
        description: 'Updated description',
        completed: true,
      });

      expect(res.statusCode).toEqual(200);
      expect(res.body.title).toBe('Updated Todo');
      expect(res.body.completed).toBe(true);
    });

    it('should return 404 if todo not found', async () => {
      Todo.findByIdAndUpdate.mockResolvedValue(null); // mock not found case

      const res = await request(app).put('/api/todos/1').send({
        title: 'Updated Todo',
      });

      expect(res.statusCode).toEqual(404);
      expect(res.body.message).toBe('Todo not found');
    });
  });

  // Test DELETE /todos/:id
  describe('DELETE /todos/:id', () => {
    it('should delete a todo by id', async () => {
      Todo.findByIdAndDelete.mockResolvedValue({ _id: '1', title: 'Todo 1' }); // mock .findByIdAndRemove()

      const res = await request(app).delete('/api/todos/1');
      expect(res.statusCode).toEqual(200);
      expect(res.body.message).toBe('Todo deleted successfully');
    });

    it('should return 404 if todo not found', async () => {
      Todo.findByIdAndDelete.mockResolvedValue(null); // mock not found case

      const res = await request(app).delete('/api/todos/1');
      expect(res.statusCode).toEqual(404);
      expect(res.body.message).toBe('Todo not found');
    });
  });
});
