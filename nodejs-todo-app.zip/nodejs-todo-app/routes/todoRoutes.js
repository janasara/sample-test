const express = require('express');
const Joi = require('joi');
const Todo = require('../models/todo');
const router = express.Router();

// Validation schema using Joi
const todoSchema = Joi.object({
  title: Joi.string().min(3).required(),
  description: Joi.string().optional(),
  completed: Joi.boolean().optional(),
});

// GET all todos
router.get('/todos', async (req, res) => {
  try {
    const todos = await Todo.find();
    res.status(200).json(todos);
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
});

// POST a new todo
router.post('/todos', async (req, res) => {
  // Validate the request body
  const { error } = todoSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ message: error.details[0].message });
  }

  const { title, description, completed } = req.body;
  try {
    const newTodo = new Todo({
      title,
      description,
      completed,
    });

    const savedTodo = await newTodo.save();
    res.status(201).json(savedTodo);
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
});

module.exports = router;
