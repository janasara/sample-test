const express = require('express');
const Joi = require('joi');
const Todo = require('../models/todo');
const router = express.Router();

// Validation schema using Joi
const todoSchema = Joi.object({
  title: Joi.string().min(3).required(),
  description: Joi.string().optional(),
  completed: Joi.boolean().optional(),
});

// GET all todos
router.get('/todos', async (req, res) => {
  try {
    const todos = await Todo.find();
    res.status(200).json(todos);
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
});

// POST a new todo using Promises
router.post('/todos', (req, res) => {
  const { error } = todoSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ message: error.details[0].message });
  }

  const { title, description, completed } = req.body;

  const newTodo = new Todo({
    title,
    description,
    completed,
  });

  newTodo
    .save()
    .then((savedTodo) => res.status(201).json(savedTodo))
    .catch((err) => res.status(500).json({ message: 'Server Error' }));
});


// PUT - update an existing todo by id using async/await
router.put('/todos/:id', async (req, res) => {
  const { error } = todoSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ message: error.details[0].message });
  }

  try {
    const updatedTodo = await Todo.findByIdAndUpdate(
      req.params.id,
      {
        $set: {
          title: req.body.title,
          description: req.body.description,
          completed: req.body.completed,
        },
      },
      { new: true }
    );

    if (!updatedTodo) {
      return res.status(404).json({ message: 'Todo not found' });
    }

    res.status(200).json(updatedTodo);
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
});


router.delete('/todos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const deletedTodo = await Todo.findByIdAndDelete(id); // Use findByIdAndDelete instead

    if (!deletedTodo) {
      return res.status(404).json({ message: 'Todo not found' });
    }

    res.status(200).json({ message: 'Todo deleted successfully' });
  } catch (err) {
    console.error('Error deleting Todo:', err);
    res.status(500).json({ message: 'Server Error', error: err.message });
  }
});



module.exports = router;
