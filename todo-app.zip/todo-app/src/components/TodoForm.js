// src/components/TodoForm.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './TodoForm.css'; // Import the CSS file

const TodoForm = ({ currentTodo, setCurrentTodo, fetchTodos }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (currentTodo) {
      setTitle(currentTodo.title);
      setDescription(currentTodo.description);
    } else {
      setTitle('');
      setDescription('');
    }
  }, [currentTodo]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (currentTodo) {
      await axios.put(`http://localhost:5000/api/todos/${currentTodo._id}`, { title, description });
    } else {
      await axios.post('http://localhost:5000/api/todos', { title, description });
    }
    fetchTodos();
    setCurrentTodo(null);
    setTitle('');
    setDescription('');
  };

  const handleCancel = () => {
    setCurrentTodo(null); // Reset the current todo state
    setTitle('');
    setDescription('');
  };

  return (
    <form className="todo-form" onSubmit={handleSubmit}>
      <h2>{currentTodo ? 'Edit Todo' : 'Add Todo'}</h2>
      <div className="form-group">
        <label htmlFor="title">Title:</label>
        <input
          type="text"
          id="title"
          className="form-input"
          placeholder="Todo Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
      </div>
      <div className="form-group">
        <label htmlFor="description">Description:</label>
        <textarea
          id="description"
          className="form-input"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
      </div>
      <div className="button-group">
        <button type="submit" className="submit-button">{currentTodo ? 'Update' : 'Add'} Todo</button>
        <button type="button" className="cancel-button" onClick={handleCancel}>Cancel</button>
      </div>
    </form>
  );
};

export default TodoForm;
