// src/components/TodoItem.js
import React from 'react';
import './TodoItem.css'; // Import the CSS file for TodoItem

const TodoItem = ({ todo, onEdit, onDelete }) => {
  return (
    <div className="todo-item">
      <h3 className="todo-title">{todo.title}</h3>
      <p className="todo-description">{todo.description}</p>
      <div className="button-group">
        <button className="edit-button" onClick={() => onEdit(todo)}>Edit</button>
        <button className="delete-button" onClick={() => onDelete(todo._id)}>Delete</button>
      </div>
    </div>
  );
};

export default TodoItem;
