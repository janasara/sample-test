// src/components/TodoList.js
import React from 'react';
import TodoItem from './TodoItem';
import './TodoList.css'; // Import the CSS file for TodoList

const TodoList = ({ todos, onEdit, onDelete }) => {
  return (
    <div className="todo-list">
      {todos.length > 0 ? (
        todos.map((todo) => (
          <TodoItem key={todo._id} todo={todo} onEdit={onEdit} onDelete={onDelete} />
        ))
      ) : (
        <p className="no-todos">No Todos available. Add a new Todo!</p>
      )}
    </div>
  );
};

export default TodoList;
