var express=require("express");
var app=express();
var mongojs=require("mongojs");
var db=mongojs('contactlist',['contactlist','login','slots','registration','slotdetails','scheduledetails']);
var bodyParser=require("body-parser")

app.use(express.static(__dirname+"/public"));
app.use(bodyParser.json());

app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});
app.get('/contactlist',function(req,res){
	console.log('I recevied a get request');
	db.contactlist.find(function(err,docs){
		console.log(docs);
		res.json(docs);
	});
});


app.post('/contactlist',function(req,res){
	console.log(req.body);
	db.contactlist.insert(req.body,function(err,doc){
		res.json(doc);
	});
});

app.delete('/contactlist/:id',function(req,res){
	var id =req.params.id;
	console.log(id);
	db.contactlist.remove({_id:mongojs.ObjectId(id)},function(err,doc){
		res.json(doc);
	});
});

app.get('/contactlist/:id', function(req,res){
	var id= req.params.id;
	console.log(id);
	db.contactlist.findOne({_id:mongojs.ObjectId(id)},function(err,doc){
		res.json(doc);
	});
});

app.get('/login/LoginName/:LoginName', function(req,res){
	var LoginName= req.params.LoginName;
	console.log(LoginName);
	db.login.find({LoginName:LoginName},function(err,doc){
		res.json(doc);
	});
});

app.get('/slots', function(req,res){
	console.log('I recevied a get request for slots');
	db.slots.find(function(err,docs){
		console.log(docs);
		res.json(docs);
	});
});
app.get('/registration',function(req,res){
	console.log('I recevied a get request registration');
	db.registration.find(function(err,docs){
		console.log(docs);
		res.json(docs);
	});
});

app.get('/slotdetails', function(req,res){
	console.log('I recevied a get request for slotsdetails');
	db.slotdetails.find(function(err,docs){
		console.log(docs);
		res.json(docs);
	});
});

app.get('/scheduledetails', function(req,res){
	console.log('I recevied a get request for scheduledetails');
	db.scheduledetails.find(function(err,docs){
		console.log(docs);
		res.json(docs);
	});
});

app.put('/contactlist/:id',function (req,res){
	var id =req.params.id;
	console.log(req.body.email);
	db.contactlist.update({ _id: mongojs.ObjectId(id)},
		  {$set: {"name": req.body.name,"email": req.body.email,"number": req.body.number}},function(err,doc){
			res.json(doc);
		});
	console.log(req.body.name);
});

app.get('/slotdetail/DocEmailId/:DocEmailId/sDate/:sDate', function(req,res){
	var DocEmailId= req.params.DocEmailId;
	var sDate= req.params.sDate;
	console.log(DocEmailId);
	console.log(sDate);
	db.slotdetails.find({$and :[{DocEmailId:DocEmailId},{Date:sDate}]},function(err,doc){
		res.json(doc);
	});
});

app.delete('/remscheduledetail/ScheduleId/:ScheduleId',function(req,res){
	console.log('I recevied a delete request for scheduledetails');
	var ScheduleId =req.params.ScheduleId;
	console.log(ScheduleId);
	db.scheduledetails.remove({ScheduleId:ScheduleId},function(err,doc){
		res.json(doc);
	});
});

app.delete('/remslotdetail/DocEmailId/:DocEmailId/SlotId/:SlotId',function(req,res){
	console.log('I recevied a delete request for slotdetail');
	var DocEmailId= req.params.DocEmailId;
	var SlotId= req.params.SlotId;
	console.log(DocEmailId);
	console.log(SlotId);
	db.slotdetails.remove({$and :[{DocEmailId:DocEmailId},{SlotId:SlotId}]},function(err,doc){
		res.json(doc);
	});
});

app.get('/searchregistrations/City/:City/SearchString/:SearchString',function(req,res){
	console.log('I recevied a get request search registrations');
	var City= req.params.City;
	var FirstName= req.params.SearchString;
	console.log(City);
	console.log(FirstName);
	db.registration.find({$and :[{City:City},{FirstName:FirstName}]},function(err,docs){
		console.log(docs);
		res.json(docs);
	});
});

app.get('/searchregistration/City/:City',function(req,res){
	console.log('I recevied a get request search registration for City');
	var City= req.params.City;
	console.log(City);
	db.registration.find({City:City},function(err,docs){
		console.log(docs);
		res.json(docs);
	});	
});

app.post('/registration',function(req,res){
	console.log(req.body);
	db.registration.insert(req.body,function(err,doc){
		res.json(doc);
	});
});

app.delete('/registration/:id',function(req,res){
	var id =req.params.id;
	console.log(id);
	db.registration.remove({_id:mongojs.ObjectId(id)},function(err,doc){
		res.json(doc);
	});
});

app.post('/scheduledetails',function(req,res){
	console.log(req.body);
	db.scheduledetails.insert(req.body,function(err,doc){
		res.json(doc);
	});
});

app.delete('/scheduledetails/:id',function(req,res){
	var id =req.params.id;
	console.log(id);
	db.scheduledetails.remove({_id:mongojs.ObjectId(id)},function(err,doc){
		res.json(doc);
	});
});

app.post('/slotdetails',function(req,res){
	console.log(req.body);
	db.slotdetails.insert(req.body,function(err,doc){
		res.json(doc);
	});
});

app.delete('/slotdetails/:id',function(req,res){
	var id =req.params.id;
	console.log(id);
	db.slotdetails.remove({_id:mongojs.ObjectId(id)},function(err,doc){
		res.json(doc);
	});
});



app.listen("5000");
console.log("Server is running in 5000");
