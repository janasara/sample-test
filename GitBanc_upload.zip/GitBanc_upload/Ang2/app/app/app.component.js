System.register(['angular2/core', 'angular2/router', 'rxjs/Rx', './Appointments/appointment.component', './Registration/registration.component', './Login/Login.component', './MyBookings/mybookings.component', './Appointments/appointment.service', './Registration/registration.service', './Login/Login.service', './MyBookings/mybookings.service', './Services/my.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, appointment_component_1, registration_component_1, Login_component_1, mybookings_component_1, appointment_service_1, registration_service_1, Login_service_1, mybookings_service_1, my_service_1;
    var AppComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (_1) {},
            function (appointment_component_1_1) {
                appointment_component_1 = appointment_component_1_1;
            },
            function (registration_component_1_1) {
                registration_component_1 = registration_component_1_1;
            },
            function (Login_component_1_1) {
                Login_component_1 = Login_component_1_1;
            },
            function (mybookings_component_1_1) {
                mybookings_component_1 = mybookings_component_1_1;
            },
            function (appointment_service_1_1) {
                appointment_service_1 = appointment_service_1_1;
            },
            function (registration_service_1_1) {
                registration_service_1 = registration_service_1_1;
            },
            function (Login_service_1_1) {
                Login_service_1 = Login_service_1_1;
            },
            function (mybookings_service_1_1) {
                mybookings_service_1 = mybookings_service_1_1;
            },
            function (my_service_1_1) {
                my_service_1 = my_service_1_1;
            }],
        execute: function() {
            AppComponent = (function () {
                function AppComponent(_myCustomService) {
                    this._myCustomService = _myCustomService;
                    this.myCustomService = _myCustomService;
                    this.myCustomService.setHeaderValue(true);
                    //_myCustomService( () => this.myCustomService.setHeaderValue(true) ); 
                }
                AppComponent.prototype.getHeaderValue = function () {
                    this.userName = this.myCustomService.getUserName().split('@')[0].toString();
                    return this.myCustomService.getHeaderValue();
                    //  return true;
                };
                AppComponent = __decorate([
                    core_1.Component({
                        selector: 'my-app',
                        templateUrl: 'app/home.html',
                        providers: [appointment_service_1.AppointmentService, registration_service_1.RegistrationService, Login_service_1.LoginService, mybookings_service_1.MyBookingService, my_service_1.MyCustomService],
                        directives: [router_1.ROUTER_DIRECTIVES]
                    }),
                    router_1.RouteConfig([
                        {
                            path: '/Login/...',
                            name: 'Login',
                            component: Login_component_1.LoginComponent,
                            useAsDefault: true
                        },
                        // {path: '/ConfirmAppointments',   name: 'ConfirmAppointments',     component: ConfirmAppointmentComponent},
                        { path: '/Appointments', name: 'Appointments', component: appointment_component_1.AppointmentComponent },
                        { path: '/Registration', name: 'Registration', component: registration_component_1.RegistrationComponent },
                        { path: '/Login', name: 'Login', component: Login_component_1.LoginComponent },
                        { path: '/MyBookings', name: 'MyBookings', component: mybookings_component_1.MyBookingsComponent }
                    ]), 
                    __metadata('design:paramtypes', [my_service_1.MyCustomService])
                ], AppComponent);
                return AppComponent;
            }());
            exports_1("AppComponent", AppComponent);
        }
    }
});
//# sourceMappingURL=app.component.js.map