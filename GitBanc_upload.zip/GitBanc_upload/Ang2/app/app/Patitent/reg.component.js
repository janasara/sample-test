System.register(["angular2/core", './registration'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, registration_1;
    var RegComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (registration_1_1) {
                registration_1 = registration_1_1;
            }],
        execute: function() {
            RegComponent = (function () {
                function RegComponent() {
                    this.usertype = ['Doctor', 'Patitent'];
                    this.specialists = ['Pediatrician', 'Oncology', 'Orthopediacs', 'Gyncology', 'Neuro'];
                    this.cities = ['Bangalore', 'Hyderabad', 'Chennai', 'Kochin'];
                    this.states = ['Andhra Pradesh', 'Karnataka', 'Telangana', 'Tamilnadu', 'Kerala'];
                    this.model = new registration_1.Registration(717768, 'Sreedhar', '', 'Davasam', this.usertype[1], '', 0, '', '', 'sreedhar.davasam@gmail.com', '9742315293', 'Lotus', 'Parimal Apts', 'Doddathogur', 'Bangalore', this.states[1], 560100);
                    this.submitted = false;
                    this.active = true;
                }
                RegComponent.prototype.onsubmit = function () { this.submitted = true; };
                RegComponent.prototype.newReg = function () {
                    var _this = this;
                    this.model = new registration_1.Registration(717768, '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', 0);
                    this.active = false;
                    setTimeout(function () { return _this.active = true; }, 0);
                };
                RegComponent = __decorate([
                    core_1.Component({
                        selector: "user-Reg",
                        templateUrl: "app/Patitent/registration.html"
                    }), 
                    __metadata('design:paramtypes', [])
                ], RegComponent);
                return RegComponent;
            }());
            exports_1("RegComponent", RegComponent);
        }
    }
});
//# sourceMappingURL=reg.component.js.map