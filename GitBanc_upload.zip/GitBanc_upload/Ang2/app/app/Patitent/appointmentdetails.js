System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var AppointmentDetails;
    return {
        setters:[],
        execute: function() {
            AppointmentDetails = (function () {
                function AppointmentDetails(id, snap, DocName, DocSpec, DocDesc, AddressDet, ConsultationFee, WeekAppointmentsList) {
                    this.id = id;
                    this.snap = snap;
                    this.DocName = DocName;
                    this.DocSpec = DocSpec;
                    this.DocDesc = DocDesc;
                    this.AddressDet = AddressDet;
                    this.ConsultationFee = ConsultationFee;
                    this.WeekAppointmentsList = WeekAppointmentsList;
                }
                return AppointmentDetails;
            }());
            exports_1("AppointmentDetails", AppointmentDetails);
        }
    }
});
//# sourceMappingURL=appointmentdetails.js.map