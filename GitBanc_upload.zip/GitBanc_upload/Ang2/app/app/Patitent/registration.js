System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Registration;
    return {
        setters:[],
        execute: function() {
            Registration = (function () {
                function Registration(id, FirstName, MiddleName, LastName, Areyou, Specialist, ConsultFee, DocQual, AboutDoc, EmailID, MobNum, Addr1, Addr2, Addr3, City, State, Pin, UserName) {
                    this.id = id;
                    this.FirstName = FirstName;
                    this.MiddleName = MiddleName;
                    this.LastName = LastName;
                    this.Areyou = Areyou;
                    this.Specialist = Specialist;
                    this.ConsultFee = ConsultFee;
                    this.DocQual = DocQual;
                    this.AboutDoc = AboutDoc;
                    this.EmailID = EmailID;
                    this.MobNum = MobNum;
                    this.Addr1 = Addr1;
                    this.Addr2 = Addr2;
                    this.Addr3 = Addr3;
                    this.City = City;
                    this.State = State;
                    this.Pin = Pin;
                    this.UserName = UserName;
                }
                return Registration;
            }());
            exports_1("Registration", Registration);
        }
    }
});
//# sourceMappingURL=registration.js.map