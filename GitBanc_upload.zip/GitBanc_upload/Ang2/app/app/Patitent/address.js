System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Address;
    return {
        setters:[],
        execute: function() {
            Address = (function () {
                function Address(id, AddressLine1, City, State, Pin, AddressLine2, AddressLine3) {
                    this.id = id;
                    this.AddressLine1 = AddressLine1;
                    this.City = City;
                    this.State = State;
                    this.Pin = Pin;
                    this.AddressLine2 = AddressLine2;
                    this.AddressLine3 = AddressLine3;
                }
                return Address;
            }());
            exports_1("Address", Address);
        }
    }
});
//# sourceMappingURL=address.js.map