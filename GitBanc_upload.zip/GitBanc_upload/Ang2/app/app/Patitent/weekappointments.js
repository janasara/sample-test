System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var WeekAppointments;
    return {
        setters:[],
        execute: function() {
            WeekAppointments = (function () {
                function WeekAppointments(id, Day, Slot1, Slot1Booked, Slot2, Slot2Booked, Slot3, Slot3Booked, Slot4, Slot4Booked, Slot5, Slot5Booked, Slot6, Slot6Booked, Slot7, Slot7Booked, Slot8, Slot8Booked, Slot9, Slot9Booked, Slot10, Slot10Booked) {
                    this.id = id;
                    this.Day = Day;
                    this.Slot1 = Slot1;
                    this.Slot1Booked = Slot1Booked;
                    this.Slot2 = Slot2;
                    this.Slot2Booked = Slot2Booked;
                    this.Slot3 = Slot3;
                    this.Slot3Booked = Slot3Booked;
                    this.Slot4 = Slot4;
                    this.Slot4Booked = Slot4Booked;
                    this.Slot5 = Slot5;
                    this.Slot5Booked = Slot5Booked;
                    this.Slot6 = Slot6;
                    this.Slot6Booked = Slot6Booked;
                    this.Slot7 = Slot7;
                    this.Slot7Booked = Slot7Booked;
                    this.Slot8 = Slot8;
                    this.Slot8Booked = Slot8Booked;
                    this.Slot9 = Slot9;
                    this.Slot9Booked = Slot9Booked;
                    this.Slot10 = Slot10;
                    this.Slot10Booked = Slot10Booked;
                }
                return WeekAppointments;
            }());
            exports_1("WeekAppointments", WeekAppointments);
        }
    }
});
//# sourceMappingURL=weekappointments.js.map