System.register(["angular2/core", './search', './address'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, search_1, address_1;
    var SearchAppointments;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (search_1_1) {
                search_1 = search_1_1;
            },
            function (address_1_1) {
                address_1 = address_1_1;
            }],
        execute: function() {
            SearchAppointments = (function () {
                function SearchAppointments() {
                    this.address = new address_1.Address(1, 'Lotus Parimal', 'Bangalore', 'Karnataka', '560100', 'Apartments', 'Doddathogur');
                    this.cities = ['Bangalore', 'Hyderabad', 'Chennai', 'Kochin', 'Amaravathi'];
                    this.submitted = false;
                    this.model = new search_1.SearchList(717768, 'Dr K N Venkataramana', 'Neuro Surgeon', 600, 9742135293, this.address, this.cities[0], '');
                    this.active = true;
                }
                SearchAppointments.prototype.onsubmit = function () { this.submitted = true; };
                SearchAppointments = __decorate([
                    core_1.Component({
                        selector: "search-app",
                        templateUrl: "app/Patitent/appointments.html"
                    }), 
                    __metadata('design:paramtypes', [])
                ], SearchAppointments);
                return SearchAppointments;
            }());
            exports_1("SearchAppointments", SearchAppointments);
        }
    }
});
//# sourceMappingURL=search.component.js.map