System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Search;
    return {
        setters:[],
        execute: function() {
            Search = (function () {
                function Search(City, SearchString, SearchDate) {
                    this.City = City;
                    this.SearchString = SearchString;
                    this.SearchDate = SearchDate;
                }
                return Search;
            }());
            exports_1("Search", Search);
        }
    }
});
//# sourceMappingURL=search.js.map