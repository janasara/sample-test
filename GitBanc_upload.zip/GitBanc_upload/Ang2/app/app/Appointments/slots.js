System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Slots;
    return {
        setters:[],
        execute: function() {
            Slots = (function () {
                function Slots(SlotId, SlotTime) {
                    this.SlotId = SlotId;
                    this.SlotTime = SlotTime;
                }
                return Slots;
            }());
            exports_1("Slots", Slots);
        }
    }
});
//# sourceMappingURL=slots.js.map