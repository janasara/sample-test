System.register(['angular2/core', 'angular2/http', 'rxjs/Observable'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, Observable_1;
    var AppointmentService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (Observable_1_1) {
                Observable_1 = Observable_1_1;
            }],
        execute: function() {
            AppointmentService = (function () {
                function AppointmentService(http) {
                    this.http = http;
                    this._regurl = 'http://saraex01.mybluemix.net/registration/';
                    this._slotDeturl = 'http://saraex01.mybluemix.net/slotdetail/';
                    this._slotsurl = 'http://saraex01.mybluemix.net/slots/';
                    this._searchRegs = 'http://saraex01.mybluemix.net/searchregistrations/';
                    this._searchReg = 'http://saraex01.mybluemix.net/searchregistration/';
                    this._remSlotDet = 'http://saraex01.mybluemix.net/remslotdetail/';
                    this._insScheduleDet = 'http://saraex01.mybluemix.net/scheduledetails/';
                }
                AppointmentService.prototype.extractData = function (res) {
                    if (res.status < 200 || res.status >= 300) {
                        throw new Error('Bad response status: ' + res.status);
                    }
                    var body = res.json();
                    return body.data || {};
                };
                AppointmentService.prototype.handleError = function (error) {
                    // In a real world app, we might send the error to remote logging infrastructure
                    var errMsg = error.message || 'Server error';
                    console.error(errMsg); // log to console instead
                    return Promise.reject(errMsg);
                };
                AppointmentService.prototype.searchSchedules = function (serCity, serString) {
                    if (serString == null || serString == '') {
                        return this.http.get(this._searchReg + "City/" + serCity)
                            .map(function (response) { return response.json(); })
                            .catch(function (error) {
                            console.log(error);
                            return Observable_1.Observable.throw(error);
                        });
                    }
                    else {
                        return this.http.get(this._searchRegs + "City/" + serCity + "/SearchString/" + serString)
                            .map(function (response) { return response.json(); })
                            .catch(function (error) {
                            console.log(error);
                            return Observable_1.Observable.throw(error);
                        });
                    }
                };
                AppointmentService.prototype.removeSlotDetail = function (selDocEmailId, slotId) {
                    return this.http.delete(this._remSlotDet + "DocEmailId/" + selDocEmailId + "/SlotId/" + slotId)
                        .map(function (response) { return response.json(); })
                        .catch(function (error) {
                        console.log(error);
                        return Observable_1.Observable.throw(error);
                    });
                };
                AppointmentService.prototype.insertScheduleDetail = function (scheduledetails) {
                    return this.http.post(this._insScheduleDet, JSON.stringify(scheduledetails), new http_1.RequestOptions({ headers: new http_1.Headers({ 'Content-Type': 'application/json' }) }))
                        .toPromise()
                        .then(this.extractData)
                        .catch(this.handleError);
                };
                AppointmentService.prototype.getAppointments = function () {
                    return this.http.get(this._regurl)
                        .map(function (response) { return response.json(); })
                        .catch(function (error) {
                        console.log(error);
                        return Observable_1.Observable.throw(error);
                    });
                };
                AppointmentService.prototype.getSlotDetails = function (selDocEmailId, selDate) {
                    return this.http.get(this._slotDeturl + "DocEmailId/" + selDocEmailId + "/sDate/" + selDate)
                        .map(function (response) { return response.json(); })
                        .catch(function (error) {
                        console.log(error);
                        return Observable_1.Observable.throw(error);
                    });
                };
                AppointmentService.prototype.getSlots = function () {
                    return this.http.get(this._slotsurl)
                        .map(function (response) { return response.json(); })
                        .catch(function (error) {
                        console.log(error);
                        return Observable_1.Observable.throw(error);
                    });
                };
                AppointmentService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], AppointmentService);
                return AppointmentService;
            }());
            exports_1("AppointmentService", AppointmentService);
        }
    }
});
//# sourceMappingURL=appointment.service.js.map