System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ScheduleDetails;
    return {
        setters:[],
        execute: function() {
            ScheduleDetails = (function () {
                function ScheduleDetails(ScheduleId, DocName, DocEmailId, DocSpecality, DocDesc, Phone, ConsFee, Addr1, Addr2, Addr3, City, State, Pin, Date, SlotId, SlotTime, SlotStatus, PatientName, PatientEmailId) {
                    this.ScheduleId = ScheduleId;
                    this.DocName = DocName;
                    this.DocEmailId = DocEmailId;
                    this.DocSpecality = DocSpecality;
                    this.DocDesc = DocDesc;
                    this.Phone = Phone;
                    this.ConsFee = ConsFee;
                    this.Addr1 = Addr1;
                    this.Addr2 = Addr2;
                    this.Addr3 = Addr3;
                    this.City = City;
                    this.State = State;
                    this.Pin = Pin;
                    this.Date = Date;
                    this.SlotId = SlotId;
                    this.SlotTime = SlotTime;
                    this.SlotStatus = SlotStatus;
                    this.PatientName = PatientName;
                    this.PatientEmailId = PatientEmailId;
                }
                return ScheduleDetails;
            }());
            exports_1("ScheduleDetails", ScheduleDetails);
        }
    }
});
//# sourceMappingURL=scheduledetails.js.map