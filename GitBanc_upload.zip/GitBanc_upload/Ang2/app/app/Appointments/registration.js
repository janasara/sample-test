System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Registration;
    return {
        setters:[],
        execute: function() {
            Registration = (function () {
                function Registration(RegId, FirstName, MiddleName, LastName, UserType, Specialist, ConsultFee, AboutDoc, EmailID, Phone, Addr1, Addr2, Addr3, City, State, Pin) {
                    this.RegId = RegId;
                    this.FirstName = FirstName;
                    this.MiddleName = MiddleName;
                    this.LastName = LastName;
                    this.UserType = UserType;
                    this.Specialist = Specialist;
                    this.ConsultFee = ConsultFee;
                    this.AboutDoc = AboutDoc;
                    this.EmailID = EmailID;
                    this.Phone = Phone;
                    this.Addr1 = Addr1;
                    this.Addr2 = Addr2;
                    this.Addr3 = Addr3;
                    this.City = City;
                    this.State = State;
                    this.Pin = Pin;
                }
                return Registration;
            }());
            exports_1("Registration", Registration);
        }
    }
});
//# sourceMappingURL=registration.js.map