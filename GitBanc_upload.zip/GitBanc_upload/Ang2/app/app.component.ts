import {Component} from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES} from 'angular2/router';
import {HTTP_PROVIDERS} from 'angular2/http';
import 'rxjs/Rx';

import {AppointmentComponent}   from './Appointments/appointment.component';
import {RegistrationComponent}   from './Registration/registration.component';
import {LoginComponent}   from './Login/Login.component';
import {MyBookingsComponent} from './MyBookings/mybookings.component';
import {AppointmentService} from './Appointments/appointment.service';
import {RegistrationService} from './Registration/registration.service';
import {LoginService}   from './Login/Login.service';
import {MyBookingService}   from './MyBookings/mybookings.service';
import {MyCustomService} from './Services/my.service';

@Component({
  selector: 'my-app',
  templateUrl:'app/home.html',
  providers:  [AppointmentService,RegistrationService,LoginService,MyBookingService,MyCustomService],
  directives: [ROUTER_DIRECTIVES]
})

@RouteConfig([
  { 
    path: '/Login/...',
    name: 'Login',
    component: LoginComponent,
    useAsDefault: true
  },
  // {path: '/ConfirmAppointments',   name: 'ConfirmAppointments',     component: ConfirmAppointmentComponent},
  {path: '/Appointments',   name: 'Appointments',     component: AppointmentComponent},
  {path: '/Registration',   name: 'Registration',     component: RegistrationComponent},
  {path: '/Login',   name: 'Login',     component: LoginComponent},
  {path: '/MyBookings',   name: 'MyBookings',     component: MyBookingsComponent}
])

export class AppComponent { 
  public myCustomService: MyCustomService;
  public userName :string;
  constructor(public _myCustomService:MyCustomService)
  {
   
    this.myCustomService = _myCustomService;
    this.myCustomService.setHeaderValue(true);
    
    //_myCustomService( () => this.myCustomService.setHeaderValue(true) ); 
  }  
  
  public getHeaderValue()
  {
    this.userName = this.myCustomService.getUserName().split('@')[0].toString();
    return this.myCustomService.getHeaderValue();
    //  return true;
  }
}
