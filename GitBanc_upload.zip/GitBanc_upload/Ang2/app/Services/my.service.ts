import {Injectable} from "angular2/core";

@Injectable()
export class MyCustomService {
    private myHeaderValue :boolean=false;
    private isLoggedin:boolean=false;
    private userName:string="";

    constructor() {
        
        this.myHeaderValue=false;
        this.isLoggedin=false;
        this.userName='';
    }

    public setHeaderValue(val:boolean) {
        this.myHeaderValue = val;
    }

    public getHeaderValue() {
        return this.myHeaderValue;
    }
    
    public setUserName(value:string) {
        this.userName = value;
    }

    public getUserName() {
        return this.userName;
    }
}