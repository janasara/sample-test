// import {bootstrap}    from 'angular2/platform/browser';
// import {AppComponent} from './app.component';

// bootstrap(AppComponent);
import {bootstrap} from 'angular2/platform/browser';
import {provide, Component} from 'angular2/core';
import {AppComponent} from './app.component';
import {HTTP_PROVIDERS} from 'angular2/http';
import {COMMON_DIRECTIVES} from 'angular2/common';

import {MyCustomService} from './services/my.service';
// import {LoginService}   from './Login/Login.service';

import {
    APP_BASE_HREF,
    ROUTER_DIRECTIVES,
    ROUTER_PROVIDERS,
    HashLocationStrategy,
    LocationStrategy
} from 'angular2/router';

bootstrap(AppComponent, [
    ROUTER_PROVIDERS,
    provide(LocationStrategy, { useClass: HashLocationStrategy }),
    provide(APP_BASE_HREF, { useValue: '/' })
]);
bootstrap(AppComponent, [ MyCustomService, COMMON_DIRECTIVES, ROUTER_DIRECTIVES, ROUTER_PROVIDERS, HTTP_PROVIDERS]);