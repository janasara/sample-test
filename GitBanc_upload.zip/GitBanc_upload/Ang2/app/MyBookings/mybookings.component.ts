
// TODO SOMEDAY: Feature Componetized like CrisisCenter
import {Component, OnInit}   from 'angular2/core';
import {Router, RouteParams} from 'angular2/router';
import {HTTP_PROVIDERS} from 'angular2/http';
import 'rxjs/Rx';

import {MyBookingService}   from './mybookings.service';
import {ScheduleDetails} from './scheduledetails';
import {MyCustomService} from '../Services/my.service';
import {SlotDetails} from './slotdetails';

@Component({
    selector: "user-Log",
  templateUrl: "app/MyBookings/mybookings.html",
  providers: [HTTP_PROVIDERS, MyBookingService] 
})
export class MyBookingsComponent implements OnInit {
  public myCustomService: MyCustomService;
  public ScheduleDetailsList: ScheduleDetails[];
  private _selectedId: number;
  private selScheduleId:string

  submitted = false;
  public remResult = false;

  constructor(
    _myCustomService:MyCustomService,
    private _service: MyBookingService,
    private _router: Router,
    routeParams: RouteParams) {
      this._selectedId = +routeParams.get('Id');
      this.myCustomService = _myCustomService;
  }
  
  remSchedule(schedObj:ScheduleDetails)
  {
    this.selScheduleId = schedObj.ScheduleId;
       this._service.delMyBookings(schedObj.ScheduleId).subscribe(
         result => {
           this.remResult = result;
         }
       )
       
      this._service.insertSlotDetails(new SlotDetails(schedObj.DocName,schedObj.DocSpecality,schedObj.DocDesc,
      schedObj.DocEmailId,schedObj.Date, schedObj.SlotId, schedObj.SlotTime, true, schedObj.PatientName,
      schedObj.PatientEmailId,schedObj.Addr1,schedObj.Addr2, schedObj.Addr3, schedObj.City, schedObj.State,
      schedObj.Pin));
      alert ('Cancel oppointment');
       //location.reload();
       this.loadScreenDetails();     
  }

  onsubmit() { this.submitted = true;}
  active = true;

  loadScreenDetails()
  {
      this._service.getMyBookings(this.myCustomService.getUserName()).subscribe(
       ScheduleDetails =>
       {
         this.ScheduleDetailsList = ScheduleDetails;
       } 
    );  
  }

  ngOnInit() {
    if(this.myCustomService.getUserName() =='')
    {
      this._router.navigate(['/Login']);
    }
    this.loadScreenDetails();  
  }
}
