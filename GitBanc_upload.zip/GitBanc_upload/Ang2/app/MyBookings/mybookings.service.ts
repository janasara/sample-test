import {Injectable} from 'angular2/core';
import {Http, RequestOptions,Response, Headers} from 'angular2/http';
import {Observable} from 'rxjs/Observable';

import {ScheduleDetails} from './scheduledetails';
import {SlotDetails} from './slotdetails';

@Injectable()
export class MyBookingService {
    
    private _scheduleDetails = 'http://saraex01.mybluemix.net/scheduledetails/';
    private _myBookurl = 'http://saraex01.mybluemix.net/userscheduledetails/';
    private _remmyBookurl = 'http://saraex01.mybluemix.net/remscheduledetail/';
    private _insSlotDeturl = 'http://saraex01.mybluemix.net/slotdetails/';
    
     constructor(private http: Http) { }

   private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body.data || { };
    }
    
    private handleError (error: any) {
        // In a real world app, we might send the error to remote logging infrastructure
        let errMsg = error.message || 'Server error';
        console.error(errMsg); // log to console instead
        return Promise.reject(errMsg);
    } 
     
     getMyBookings(PatientEmailId) {
         
         return this.http.get(this._myBookurl+"PatientEmailId/"+PatientEmailId)
         .map(response => <ScheduleDetails[]>response.json())
         .catch(error => {
            console.log(error);
            return Observable.throw(error);             
         });
     }
     
     delMyBookings(ScheduleId){
         return this.http.delete(this._remmyBookurl + "ScheduleId/" +ScheduleId)
         .map(response => <boolean>response.json())
         .catch(error => {
            console.log(error);
            return Observable.throw(error);             
         }); 
     }
     
     insertSlotDetails(slotDet:SlotDetails){
        return this.http.post(this._insSlotDeturl,JSON.stringify(slotDet),
            new RequestOptions({ headers: new Headers({'Content-Type': 'application/json'}) }) )
            .toPromise()
            .then(this.extractData)
                .catch(this.handleError);         
     }
}