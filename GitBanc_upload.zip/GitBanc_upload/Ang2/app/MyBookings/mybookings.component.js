System.register(['angular2/core', 'angular2/router', 'angular2/http', 'rxjs/Rx', './mybookings.service', '../Services/my.service', './slotdetails'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, http_1, mybookings_service_1, my_service_1, slotdetails_1;
    var MyBookingsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (mybookings_service_1_1) {
                mybookings_service_1 = mybookings_service_1_1;
            },
            function (my_service_1_1) {
                my_service_1 = my_service_1_1;
            },
            function (slotdetails_1_1) {
                slotdetails_1 = slotdetails_1_1;
            }],
        execute: function() {
            MyBookingsComponent = (function () {
                function MyBookingsComponent(_myCustomService, _service, _router, routeParams) {
                    this._service = _service;
                    this._router = _router;
                    this.submitted = false;
                    this.remResult = false;
                    this.active = true;
                    this._selectedId = +routeParams.get('Id');
                    this.myCustomService = _myCustomService;
                }
                MyBookingsComponent.prototype.remSchedule = function (schedObj) {
                    var _this = this;
                    this.selScheduleId = schedObj.ScheduleId;
                    this._service.delMyBookings(schedObj.ScheduleId).subscribe(function (result) {
                        _this.remResult = result;
                    });
                    this._service.insertSlotDetails(new slotdetails_1.SlotDetails(schedObj.DocName, schedObj.DocSpecality, schedObj.DocDesc, schedObj.DocEmailId, schedObj.Date, schedObj.SlotId, schedObj.SlotTime, true, schedObj.PatientName, schedObj.PatientEmailId, schedObj.Addr1, schedObj.Addr2, schedObj.Addr3, schedObj.City, schedObj.State, schedObj.Pin));
                    //location.reload();
                    alert ('Cancel oppointment');
                    this.loadScreenDetails();
                };
                MyBookingsComponent.prototype.onsubmit = function () { this.submitted = true; };
                MyBookingsComponent.prototype.loadScreenDetails = function () {
                    var _this = this;
                    this._service.getMyBookings(this.myCustomService.getUserName()).subscribe(function (ScheduleDetails) {
                        _this.ScheduleDetailsList = ScheduleDetails;
                    });
                };
                MyBookingsComponent.prototype.ngOnInit = function () {
                    if (this.myCustomService.getUserName() == '') {
                        this._router.navigate(['/Login']);
                    }
                    this.loadScreenDetails();
                };
                MyBookingsComponent = __decorate([
                    core_1.Component({
                        selector: "user-Log",
                        templateUrl: "app/MyBookings/mybookings.html",
                        providers: [http_1.HTTP_PROVIDERS, mybookings_service_1.MyBookingService]
                    }), 
                    __metadata('design:paramtypes', [my_service_1.MyCustomService, mybookings_service_1.MyBookingService, router_1.Router, router_1.RouteParams])
                ], MyBookingsComponent);
                return MyBookingsComponent;
            }());
            exports_1("MyBookingsComponent", MyBookingsComponent);
        }
    }
});
//# sourceMappingURL=mybookings.component.js.map