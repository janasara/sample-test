System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var SearchList;
    return {
        setters:[],
        execute: function() {
            SearchList = (function () {
                function SearchList(id, DocName, DocDetails, CosultationFee, ContNum, AddressDet, searchLoc, SearchDocHos, Snap) {
                    this.id = id;
                    this.DocName = DocName;
                    this.DocDetails = DocDetails;
                    this.CosultationFee = CosultationFee;
                    this.ContNum = ContNum;
                    this.AddressDet = AddressDet;
                    this.searchLoc = searchLoc;
                    this.SearchDocHos = SearchDocHos;
                    this.Snap = Snap;
                }
                return SearchList;
            }());
            exports_1("SearchList", SearchList);
        }
    }
});
//# sourceMappingURL=search.js.map