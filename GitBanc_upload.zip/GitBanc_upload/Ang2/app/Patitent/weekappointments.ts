export class WeekAppointments
{
    constructor (
        public id: number,
        public Day: string,
        public Slot1: string,
        public Slot1Booked: boolean,
        public Slot2: string,
        public Slot2Booked: boolean,
        public Slot3: string,
        public Slot3Booked: boolean,
        public Slot4: string,
        public Slot4Booked: boolean,
        public Slot5: string,
        public Slot5Booked: boolean,
        public Slot6: string,
        public Slot6Booked: boolean,
        public Slot7: string,
        public Slot7Booked: boolean,
        public Slot8: string,
        public Slot8Booked: boolean,
        public Slot9: string,
        public Slot9Booked: boolean,
        public Slot10: string,
        public Slot10Booked: boolean                                                                        
    ){}
}