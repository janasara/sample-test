import {Address} from './address';

export class SearchList{
    constructor(
    public id: number,
    public DocName: string,
    public DocDetails:string,
    public CosultationFee: number,
    public ContNum: number,
    public AddressDet: Address,
    public searchLoc?: string,
    public SearchDocHos?: string,
    public Snap?: Blob    
    ){}
}