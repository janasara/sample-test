import {Component} from "angular2/core"
import {NgForm}    from 'angular2/common';
import {SearchList} from './search';
import {AppointmentDetails} from './appointmentdetails';
import {Address} from './address';

@Component({
    selector: "search-app",
    templateUrl: "app/Patitent/appointments.html"
})

export class SearchAppointments{
    address = new Address(1,'Lotus Parimal','Bangalore','Karnataka','560100', 'Apartments', 'Doddathogur');
    cities =['Bangalore', 'Hyderabad', 'Chennai', 'Kochin', 'Amaravathi'];
    submitted = false;
    onsubmit() { this.submitted = true;}
     
    model = new SearchList(717768,'Dr K N Venkataramana', 'Neuro Surgeon', 600, 9742135293, this.address, this.cities[0],'');     
    active = true;
}