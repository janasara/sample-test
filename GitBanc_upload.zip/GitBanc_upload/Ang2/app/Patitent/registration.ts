export class Registration{
    constructor(
    public id: number,
    public FirstName: string,
    public MiddleName: string,
    public LastName: string,
    public Areyou: string,
    public Specialist: string,
    public ConsultFee: number,
    public DocQual: string,
    public AboutDoc: string,
    public EmailID:string,
    public MobNum: string,
    public Addr1: string,
    public Addr2: string,
    public Addr3: string,
    public City: string,
    public State: string,
    public Pin: number,
    public UserName: string
    ){}
}