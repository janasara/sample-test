import {Address} from './address';
import {WeekAppointments} from './weekappointments';

export class AppointmentDetails{
    constructor(
        public id: number,
        public snap: Blob,
        public DocName: string,
        public DocSpec: string,
        public DocDesc: string,
        public AddressDet: Address,
        public ConsultationFee: string,
        public WeekAppointmentsList : WeekAppointments[]
    )
    {}
}