import {Component} from "angular2/core"
import {NgForm}    from 'angular2/common';
import {Registration} from './registration';

@Component ({
  selector: "user-Reg",
  templateUrl: "app/Patitent/registration.html"
})

export class RegComponent{    
    
    usertype = ['Doctor', 'Patitent'];
    specialists = ['Pediatrician','Oncology','Orthopediacs','Gyncology','Neuro'];
    cities =['Bangalore', 'Hyderabad', 'Chennai', 'Kochin'];
    states = ['Andhra Pradesh', 'Karnataka', 'Telangana', 'Tamilnadu', 'Kerala'];
    model = new Registration(717768,'Sreedhar', '', 'Davasam', this.usertype[1], '',0,'','','sreedhar.davasam@gmail.com',
    '9742315293', 'Lotus', 'Parimal Apts', 'Doddathogur', 'Bangalore', this.states[1], 560100);
    
    submitted = false;
    
    onsubmit() { this.submitted = true;}
    
    active = true;
    
    newReg() {
        this.model = new Registration(717768,'', '', '', '', '',0,'','','',
    '', '', '', '', '', '', 0);
    this.active = false;
    setTimeout(()=> this.active=true, 0);
    }
}