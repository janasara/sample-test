export class Address{
    constructor(
        public id: number,
        public AddressLine1: string,
        public City: string,
        public State: string,
        public Pin: string,
        public AddressLine2?:string,
        public AddressLine3?:string
    )
    {}
}