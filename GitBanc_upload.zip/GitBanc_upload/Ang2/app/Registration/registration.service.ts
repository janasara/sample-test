import {Injectable} from 'angular2/core';
import {Http, RequestOptions,Response, Headers} from 'angular2/http';
import {Observable} from 'rxjs/Observable';

import {Registration} from './registration';
// import {LoginService}   from '../Login/login.service';
import {Login} from '../Login/login';

@Injectable()
export class RegistrationService {
   private _userRegurl = 'http://saraex01.mybluemix.net/registration/';
   private _loginurl = 'http://saraex01.mybluemix.net/login/';
   
    constructor(private http: Http) { }
   
   private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body.data || { };
    }
    
    private handleError (error: any) {
        // In a real world app, we might send the error to remote logging infrastructure
        let errMsg = error.message || 'Server error';
        console.error(errMsg); // log to console instead
        return Promise.reject(errMsg);
    }    
   
   saveRegDetails(regObj:Registration) {
            this.http.post(this._userRegurl,JSON.stringify(regObj),
            new RequestOptions({ headers: new Headers({'Content-Type': 'application/json'})}))
            .toPromise()
            .then(this.extractData)
                .catch(this.handleError);
                
            return this.insertLoginDetails(regObj);
        }
        
    insertLoginDetails(regObj:Registration)
    {
        return this.http.post(this._loginurl,JSON.stringify(new Login(regObj.EmailID, regObj.EmailID)),
            new RequestOptions({ headers: new Headers({'Content-Type': 'application/json'})}))
            .toPromise()
            .then(this.extractData)
                .catch(this.handleError);
    }
}

