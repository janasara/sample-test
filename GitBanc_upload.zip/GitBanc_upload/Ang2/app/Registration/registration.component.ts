import {Component, OnInit}   from 'angular2/core';
import {Router, RouteParams} from 'angular2/router';
import {HTTP_PROVIDERS} from 'angular2/http';
import 'rxjs/Rx';

import {RegistrationService} from './registration.service';
import {Registration} from './registration';

@Component ({
  selector: "user-Reg",
  templateUrl: "app/Registration/registration.html",
  providers: [HTTP_PROVIDERS, RegistrationService] 
})

export class RegistrationComponent implements OnInit{    
    
     private _selectedId: number;
     public setStatus:string;
     public usertype = ['Doctor', 'Patitent'];
     public specialists = ['Pediatrician','Oncology','Orthopediacs','Gynacology','Neuro'];
     public cities =['Bangalore', 'Hyderabad', 'Chennai', 'Kochin', 'Amaravathi'];
     public states = ['Andhra Pradesh', 'Karnataka', 'Telangana', 'Tamilnadu', 'Kerala'];
      public model;     
      constructor(
        private _service: RegistrationService,
        private _router: Router,
        routeParams: RouteParams) {
        this._selectedId = +routeParams.get('id');
    }

    saveUserDetails(objuserDet:Registration)
    {
      // if (objuserDet.FirstName != 'Sreedhar')
      {
         this._service.saveRegDetails(objuserDet)
         alert("User Details Saved successfully.");
        //  this.setStatus = "User Details Saved successfully."
        //  setTimeout(this.routePage, 3000);         
        this._router.navigate(['/Login']);
      }
    }
    
    routePage()
    {
      this._router.navigate(['/Login']);
    }
    
    ngOnInit() {
              this.model = new Registration(Date.now(),'', '', '', this.usertype[1], '',0,'','x@y.com',
    '9999999999', 'Infosys', 'ECity', 'Doddathogur', 'Bangalore', this.states[1], "560100");
    }
}
