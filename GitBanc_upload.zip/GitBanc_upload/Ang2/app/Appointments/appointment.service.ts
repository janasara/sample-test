import {Injectable} from 'angular2/core';
import {Http, RequestOptions,Response, Headers} from 'angular2/http';
import {Observable} from 'rxjs/Observable';

import {Registration} from './registration';
import {Slots} from './slots';
import {SlotDetails} from './slotdetails';
import {ScheduleDetails} from './scheduledetails';

@Injectable()
export class AppointmentService {
    
   private _regurl = 'http://saraex01.mybluemix.net/registration/';
   private _slotDeturl = 'http://saraex01.mybluemix.net/slotdetail/';
   private _slotsurl = 'http://saraex01.mybluemix.net/slots/';
   private _searchRegs = 'http://saraex01.mybluemix.net/searchregistrations/';
   private _searchReg = 'http://saraex01.mybluemix.net/searchregistration/';
   private _remSlotDet = 'http://saraex01.mybluemix.net/remslotdetail/';
   private _insScheduleDet = 'http://saraex01.mybluemix.net/scheduledetails/';
    
   constructor(private http: Http) { }
   
   private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body.data || { };
    }
    
    private handleError (error: any) {
        // In a real world app, we might send the error to remote logging infrastructure
        let errMsg = error.message || 'Server error';
        console.error(errMsg); // log to console instead
        return Promise.reject(errMsg);
    } 
   
   searchSchedules(serCity, serString)
   {
       if (serString== null || serString == '')
       {
        return this.http.get(this._searchReg+"City/"+serCity)
            .map(response => <Registration[]>response.json())
            .catch(error => {
                    console.log(error);
                    return Observable.throw(error);
                });           
       }
       else
       {
        return this.http.get(this._searchRegs+"City/"+serCity+"/SearchString/"+serString)
            .map(response => <Registration[]>response.json())
            .catch(error => {
                    console.log(error);
                    return Observable.throw(error);
                });
       }
   }
    
    removeSlotDetail(selDocEmailId, slotId){
        return this.http.delete(this._remSlotDet+"DocEmailId/"+selDocEmailId+"/SlotId/"+slotId)
         .map(response => <boolean>response.json())
         .catch(error => {
            console.log(error);
            return Observable.throw(error);             
         }); 
    }
    
    insertScheduleDetail(scheduledetails: ScheduleDetails){
        return this.http.post(this._insScheduleDet,JSON.stringify(scheduledetails),
            new RequestOptions({ headers: new Headers({'Content-Type': 'application/json'})}))
            .toPromise()
            .then(this.extractData)
                .catch(this.handleError);
    }
    
    getAppointments() {
       return this.http.get(this._regurl)
        .map(response => <Registration[]>response.json())
        .catch(error => {
                console.log(error);
                return Observable.throw(error);
            });
     }
     
     getSlotDetails(selDocEmailId, selDate){
         return this.http.get(this._slotDeturl+"DocEmailId/"+selDocEmailId+"/sDate/"+selDate)
        .map(response => <SlotDetails[]>response.json())
        .catch(error => {
                console.log(error);
                return Observable.throw(error);
            });
     }
     
     getSlots(){
         return this.http.get(this._slotsurl)
        .map(response => <Slots[]>response.json())
        .catch(error => {
                console.log(error);
                return Observable.throw(error);
            });
     }
}

