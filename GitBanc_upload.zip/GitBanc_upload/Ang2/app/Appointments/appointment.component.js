System.register(['angular2/core', 'angular2/router', 'angular2/http', 'rxjs/Rx', './appointment.service', './search', './scheduleDetails', '../Services/my.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, http_1, appointment_service_1, search_1, scheduledetails_1, my_service_1;
    var AppointmentComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (_1) {},
            function (appointment_service_1_1) {
                appointment_service_1 = appointment_service_1_1;
            },
            function (search_1_1) {
                search_1 = search_1_1;
            },
            function (scheduledetails_1_1) {
                scheduledetails_1 = scheduledetails_1_1;
            },
            function (my_service_1_1) {
                my_service_1 = my_service_1_1;
            }],
        execute: function() {
            AppointmentComponent = (function () {
                function AppointmentComponent(_myCustomService, _service, _router, routeParams) {
                    this._service = _service;
                    this._router = _router;
                    this.selDate = "05-05-2016";
                    this.selDateandTime = this.selDate + "  ";
                    this.selMob = "08046104610";
                    this.submitted = false;
                    this.showDocDet = false;
                    this.selSlotID = 0;
                    this.resp = false;
                    this.cities = ['Bangalore', 'Hyderabad', 'Chennai', 'Kochin', 'Amaravathi'];
                    this.active = true;
                    this._selectedId = +routeParams.get('id');
                    this.myCustomService = _myCustomService;
                    this.myCustomService.setHeaderValue(false);
                }
                AppointmentComponent.prototype.onsubmit = function () { this.submitted = true; };
                AppointmentComponent.prototype.searchSchedules = function () {
                    var _this = this;
                    this.selCity = this.searchObject.City;
                    this.searchString = this.searchObject.SearchString;
                    this._service.searchSchedules(this.searchObject.City, this.searchObject.SearchString).subscribe(function (Registrations) {
                        _this.RegistrationsList = Registrations;
                    });
                };
                AppointmentComponent.prototype.UpdateSlotDetails = function () {
                    var _this = this;
                    this._service.removeSlotDetail(this.selDocEmailId, this.selSlotID).subscribe(function (resp) {
                        _this.resp = resp;
                    });
                    this._service.insertScheduleDetail(new scheduledetails_1.ScheduleDetails(Date.now().toString(), this.selDocName, this.selDocEmailId, this.selDocSpeciality, this.selDOcDesc, "08046104610", 500, this.selAddr1, this.selAddr2, this.selAddr3, this.selCity, this.selState, "560100", this.userDate, this.selSlotID, this.selSlotTime, true, this.selPatName, this.selPatEmailId));
                    alert ('Schedule is confirmed');
                    this.showScheduleDetails();
                };
                AppointmentComponent.prototype.scheduleDetails = function (docObj) {
                    this.selDocName = docObj.FirstName;
                    this.selDocEmailId = docObj.EmailID;
                    this.selMob = docObj.Phone;
                    this.selAddr1 = docObj.Addr1;
                    this.selAddr2 = docObj.Addr2;
                    this.selAddr3 = docObj.Addr3;
                    this.selDocSpeciality = docObj.Specialist;
                    this.selDOcDesc = docObj.AboutDoc;
                    // this.selDate  = toDateString(Date.now);
                    this.selCity = docObj.City;
                    this.selState = docObj.State;
                    this.selPin = docObj.Pin;
                    // this.searchDoc = searchDoc.value;
                    this.submitted = true;
                };
                AppointmentComponent.prototype.setSelectedDetails = function (selSlotDet) {
                    this.selDocName = selSlotDet.DocName;
                    this.selDocEmailId = selSlotDet.DocEmailId;
                    // this.selDocSpeciality = selSlotDet.Specialist;
                    // this.selDOcDesc = selSlotDet.AboutDoc;
                    this.selCity = selSlotDet.City;
                    this.selState = selSlotDet.State;
                    this.selPin = selSlotDet.Pin;
                    this.selPatName = this.myCustomService.getUserName().split('@')[0].toString();
                    this.selPatEmailId = this.myCustomService.getUserName();
                    this.selDateandTime = this.selDate + "  " + selSlotDet.SlotTime;
                    this.selSlotID = selSlotDet.SlotId;
                    this.userDate = selSlotDet.Date;
                    this.selSlotTime = selSlotDet.SlotTime;
                };
                AppointmentComponent.prototype.showScheduleDetails = function () {
                    var _this = this;
                    this.showDocDet = true;
                    this.selDate = this.searchObject.SearchDate;
                    this._service.getSlotDetails(this.selDocEmailId, this.selDate).subscribe(function (slotDetails) {
                        _this.SlotDetailsList = slotDetails;
                    });
                };
                AppointmentComponent.prototype.ngOnInit = function () {
                    if (this.myCustomService.getUserName() == '') {
                        this._router.navigate(['/Login']);
                    }
                    this.searchObject = new search_1.Search('Bangalore', '', '05-05-2016');
                    //  this._service.getAppointments().subscribe(
                    //    Registrations =>
                    //    {
                    //      this.RegistrationsList = Registrations;
                    //    } 
                    //  )
                };
                AppointmentComponent = __decorate([
                    core_1.Component({
                        selector: "user-appointment",
                        templateUrl: "app/Appointments/appointments.html",
                        providers: [http_1.HTTP_PROVIDERS, appointment_service_1.AppointmentService]
                    }), 
                    __metadata('design:paramtypes', [my_service_1.MyCustomService, appointment_service_1.AppointmentService, router_1.Router, router_1.RouteParams])
                ], AppointmentComponent);
                return AppointmentComponent;
            }());
            exports_1("AppointmentComponent", AppointmentComponent);
        }
    }
});
//# sourceMappingURL=appointment.component.js.map