import {Component, OnInit,provide, ViewContainerRef}   from 'angular2/core';
import {Router, RouteParams} from 'angular2/router';
import {HTTP_PROVIDERS} from 'angular2/http';
import 'rxjs/Rx';
import {CORE_DIRECTIVES, FORM_DIRECTIVES} from 'angular2/common';

import {AppointmentService}   from './appointment.service';
import {Registration}  from './registration';
import {SlotDetails} from './slotdetails';
import {Search} from './search';
import {ScheduleDetails} from './scheduledetails';
import {MyCustomService} from '../Services/my.service';

@Component({
   selector:"user-appointment",
   templateUrl: "app/Appointments/Appointments.html",
   providers: [HTTP_PROVIDERS, AppointmentService] 
})

export class AppointmentComponent implements OnInit {
  public RegistrationsList: Registration[];
  public SlotDetailsList: SlotDetails[];
  private _selectedId: number;  
  public searchString: string;
  public selDocName: string; 
  public selDate = "05-05-2016";
  public userDate:number;
  public selDateandTime = this.selDate +"  " 
  public selDocEmailId:string;
  public selPatEmailId:string;
  public selPatName:string;
  public selMob = "08046104610";
  public selAddr1:string;
  public selAddr2:string;
  public selAddr3:string;
  public submitted = false;
  public showDocDet = false; 
  public selCity:string;
  public selState:string;
  public selPin:string;
  public searchDoc: string;
  public searchObject : Search;
  public selSlotID =0;
  public selSlotTime:string;
  public selSlotStatus:boolean;
  public selDocSpeciality:string;
  public selDOcDesc:string;
  private resp= false;
  
  public cities =['Bangalore', 'Hyderabad', 'Chennai', 'Kochin', 'Amaravathi'];
  public myCustomService: MyCustomService;
  constructor(
   _myCustomService:MyCustomService,
    private _service: AppointmentService,
    private _router: Router,
    routeParams: RouteParams) {
      this._selectedId = +routeParams.get('id');
      this.myCustomService = _myCustomService;
      this.myCustomService.setHeaderValue(false);     
  }
    
   onsubmit() { this.submitted = true; }
    active = true;
    
 searchSchedules(){
    this.selCity = this.searchObject.City;
    this.searchString = this.searchObject.SearchString;
    this._service.searchSchedules(this.searchObject.City,this.searchObject.SearchString ).subscribe(
       Registrations =>
       {
         this.RegistrationsList = Registrations;
       } 
     )
 }   
 
 UpdateSlotDetails(){

   this._service.removeSlotDetail(this.selDocEmailId, this.selSlotID ).subscribe(
       resp =>
       {
         this.resp = resp;
       } 
    )

    this._service.insertScheduleDetail(new ScheduleDetails(Date.now().toString(),this.selDocName,this.selDocEmailId,
        this.selDocSpeciality,this.selDOcDesc,"08046104610", 500,this.selAddr1,this.selAddr2,this.selAddr3,
        this.selCity,this.selState,"560100",this.userDate,this.selSlotID,this.selSlotTime,
        true,this.selPatName,this.selPatEmailId) );
    alert ('Schedule is confirmed');
    this.showScheduleDetails();
    
 }   
    
  scheduleDetails( docObj : Registration)
  {
    this.selDocName = docObj.FirstName;
    this.selDocEmailId = docObj.EmailID;
    this.selMob = docObj.Phone;
    this.selAddr1 = docObj.Addr1;
    this.selAddr2 = docObj.Addr2;
    this.selAddr3 = docObj.Addr3;
    this.selDocSpeciality = docObj.Specialist;
    this.selDOcDesc = docObj.AboutDoc;
    // this.selDate  = toDateString(Date.now);
    this.selCity = docObj.City;
    this.selState = docObj.State;
    this.selPin = docObj.Pin;
    
    // this.searchDoc = searchDoc.value;
    this.submitted = true;
  }
  
  setSelectedDetails(selSlotDet:SlotDetails)
  {
      this.selDocName = selSlotDet.DocName;
      this.selDocEmailId =  selSlotDet.DocEmailId;
      // this.selDocSpeciality = selSlotDet.Specialist;
      // this.selDOcDesc = selSlotDet.AboutDoc;
      this.selCity = selSlotDet.City;
      this.selState = selSlotDet.State;
      this.selPin = selSlotDet.Pin;
      this.selPatName = this.myCustomService.getUserName().split('@')[0].toString();
      this.selPatEmailId = this.myCustomService.getUserName();
      this.selDateandTime = this.selDate +"  " + selSlotDet.SlotTime;
      this.selSlotID = selSlotDet.SlotId;
      this.userDate = selSlotDet.Date;
      this.selSlotStatus = selSlotDet.SlotStatus;
      this.selSlotTime = selSlotDet.SlotTime;
  }
  
  showScheduleDetails()
  {
      this.showDocDet = true;
      this.selDate = this.searchObject.SearchDate;
      this._service.getSlotDetails(this.selDocEmailId, this.selDate).subscribe( 
       slotDetails =>
       {
         this.SlotDetailsList = slotDetails;
       } );
  }
  
  ngOnInit() {
    
    if(this.myCustomService.getUserName() =='')
    {
      this._router.navigate(['/Login']);
    }
    this.searchObject = new Search('Bangalore','', '05-05-2016');
    //  this._service.getAppointments().subscribe(
    //    Registrations =>
    //    {
    //      this.RegistrationsList = Registrations;
    //    } 
    //  )
  }
}
