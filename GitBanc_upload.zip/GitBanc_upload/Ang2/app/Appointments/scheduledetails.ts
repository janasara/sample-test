export class ScheduleDetails{
    constructor(
        public ScheduleId: string,
        public DocName: string,
        public DocEmailId : string,
        public DocSpecality: string,
        public DocDesc: string,
        public Phone: string, 
        public ConsFee: number,
        public Addr1: string,
        public Addr2: string,
        public Addr3: string,
        public City: string,
        public State: string,
        public Pin: string ,
        public Date: number,
        public SlotId: number,
        public SlotTime: string,
        public SlotStatus: boolean,
        public PatientName : string,
        public PatientEmailId: string
    ){}
}