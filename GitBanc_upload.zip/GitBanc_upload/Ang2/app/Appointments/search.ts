export class Search{
    constructor(
        public City: string,
        public SearchString: string,
        public SearchDate: string
    ){}
}