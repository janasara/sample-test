export class Slots{
    constructor(
        public SlotId: number,
        public SlotTime: string
    ){}
}