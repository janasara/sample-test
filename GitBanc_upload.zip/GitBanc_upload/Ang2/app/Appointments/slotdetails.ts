export class SlotDetails{
    constructor(
        public DocName: string,
        public Specialist: string,
        public AboutDoc: string,
        public DocEmailId : string,
        public Date: number, 
        public SlotId: number,
        public SlotTime: string,
        public SlotStatus: boolean,
        public PatientName: string,
        public PatientEmailId: string,
        public Addr1: string,
        public Addr2: string,
        public Addr3: string,
        public City: string,
        public State: string,
        public Pin: string
    ){}
}