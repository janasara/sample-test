export class Registration{
    constructor(
    public RegId: number,
    public FirstName: string,
    public MiddleName: string,
    public LastName: string,
    public UserType: string,
    public Specialist: string,
    public ConsultFee: number,
    public AboutDoc: string,
    public EmailID:string,
    public Phone: string,
    public Addr1: string,
    public Addr2: string,
    public Addr3: string,
    public City: string,
    public State: string,
    public Pin: string
    ){}
}