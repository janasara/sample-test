import {Injectable} from 'angular2/core';
import {Http, RequestOptions,Response, Headers} from 'angular2/http';
import {Observable} from 'rxjs/Observable';

import {Login} from './login';

@Injectable()
export class LoginService {
 
// private _loginurl = 'http://saraex01.mybluemix.net/login/';

 private _loginurl = 'http://localhost:5000/';
  
 constructor(private http: Http) { }
    
    
   private extractData(res: Response) {
        if (res.status < 200 || res.status >= 300) {
            throw new Error('Bad response status: ' + res.status);
        }
        let body = res.json();
        return body.data || { };
    }
    
    private handleError (error: any) {
        // In a real world app, we might send the error to remote logging infrastructure
        let errMsg = error.message || 'Server error';
        console.error(errMsg); // log to console instead
        return Promise.reject(errMsg);
    }     
    
    validateUser(loginObj: Login)
    {
        // console.log("Login Service" + loginObj.LoginName);
        return this.http.get(this._loginurl+"LoginName/"+loginObj.LoginName)
            .map(response => <Login>response.json())
            .catch(error => {
                    console.log(error);
                    return Observable.throw(error);
                });           
    } 
    
    InsertLoginUser(loginObj: Login)
    {
        return this.http.post(this._loginurl,JSON.stringify(loginObj),
            new RequestOptions({ headers: new Headers({'Content-Type': 'application/json'})}))
            .toPromise()
            .then(this.extractData)
                .catch(this.handleError);
    }
    
//     removeSlotDetail(loginObj){
//     return this.http.get(this._loginurl+"LoginName/"+loginObj.LoginName)
//         .map(response => <Login>response.json())
//         .catch(error => {
//             console.log(error);
//             return Observable.throw(error);             
//         }); 
// }   
}