export class Login{
    constructor(
        public LoginName: string, 
        public Password: string
    ){}
}