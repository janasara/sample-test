import {Component, OnInit} from 'angular2/core';
import {FORM_PROVIDERS, FormBuilder, Validators} from 'angular2/common';
import {HTTP_PROVIDERS} from 'angular2/http';

import {LoginService}   from './login.service';
import {Login} from './login';
import {Router, RouteParams} from 'angular2/router';
import {MyCustomService} from '../Services/my.service';

@Component({
    selector: "user-Log",
  templateUrl: "app/Login/Login.html" ,
  providers: [HTTP_PROVIDERS, LoginService]
})

export class LoginComponent implements OnInit {
  //  public myCustomService: MyCustomService;
      
      private userDet :Login;
      public validateUserStatus:string;
      public model = new Login('','');
    constructor(
      private _router: Router,      
      private _myCustomService:MyCustomService,
      private _service: LoginService) {
       // this._formbuilder=fb;
      // this.myCustomService = _myCustomService;
      this._myCustomService.setHeaderValue(true);      
  }
  
      // onsubmit() {
      //    this.myCustomService.setUserName("");
      //   this.submitted = true;
      // }
    active = true;
       
    doLogin(userObj) 
    {
      this._service.validateUser(userObj).subscribe( 
      validateUser => this.userDet = validateUser);
      console.log(this.userDet);   
         
      if(this.userDet != null && this.userDet.LoginName != '')
      {    
        this._myCustomService.setUserName(userObj.LoginName);
        this._router.navigate(['/Appointments']);        
      }
      else if(this.userDet == null)
      {
        this.validateUserStatus = ""
      }
      else{
          this.validateUserStatus = "Login Failed, Please try again Later ";
      }
  }
  
  gotoSignup()
  {
    this._router.navigate(['/Registration']);
  }
    gotoLogin()
  {
    this._router.navigate(['/Login']);
  }
  
   ngOnInit() {
     this.userDet = null;

   }
}
